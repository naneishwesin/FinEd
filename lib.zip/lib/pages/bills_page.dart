// lib/pages/bills_page.dart
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import 'detailed_expenses_page.dart';
import 'detailed_income_page.dart';

class BillsPage extends StatefulWidget {
  @override
  _BillsPageState createState() => _BillsPageState();
}

class _BillsPageState extends State<BillsPage> {
  String _searchQuery = "";
  String _selectedFilter = "All";
  String _selectedView = "overview"; // "overview", "expenses", "income"
  String _calendarView = "expense"; // "expense" or "income"
  String get _selectedMonth => _getCurrentMonth();

  String _getCurrentMonth() {
    final now = DateTime.now();
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return '${months[now.month - 1]} ${now.year}';
  }

  // Sample data - in real app, this would come from a database or state management
  final List<Map<String, dynamic>> _transactions = [
    {
      "category": "🍕 Food & Dining",
      "amount": -450,
      "date": DateTime.now()
          .subtract(const Duration(days: 1))
          .toString()
          .split(' ')[0],
      "time": "12:00",
      "asset": "Cash",
      "ledger": "Personal",
      "remark": "Good",
      "type": "expense",
    },
    {
      "category": "🍕 Food & Dining",
      "amount": -120,
      "date": DateTime.now()
          .subtract(const Duration(days: 2))
          .toString()
          .split(' ')[0],
      "time": "18:00",
      "asset": "Credit Card",
      "ledger": "Personal",
      "remark": "Good",
      "type": "expense",
    },
    {
      "category": "🚗 Transportation",
      "amount": -320,
      "date": DateTime.now()
          .subtract(const Duration(days: 3))
          .toString()
          .split(' ')[0],
      "time": "09:00",
      "asset": "Cash",
      "ledger": "Personal",
      "remark": "Good",
      "type": "expense",
    },
    {
      "category": "🎬 Entertainment",
      "amount": -800,
      "date": "Sep 18, 20:00",
      "type": "expense",
    },
    {
      "category": "🛒 Shopping",
      "amount": -1200,
      "date": "Sep 17, 14:00",
      "type": "expense",
    },
    {
      "category": "⚡ Utilities",
      "amount": -800,
      "date": "Sep 16, 10:00",
      "type": "expense",
    },
    {
      "category": "🏠 Rent",
      "amount": -8000,
      "date": "Sep 15, 09:00",
      "type": "expense",
    },
    {
      "category": "💼 Salary",
      "amount": 25000,
      "date": "Sep 14, 09:00",
      "type": "income",
    },
    {
      "category": "💻 Freelance",
      "amount": 3000,
      "date": "Sep 13, 15:00",
      "type": "income",
    },
    {
      "category": "🚕 Transportation",
      "amount": -150,
      "date": "Sep 12, 18:00",
      "type": "expense",
    },
    {
      "category": "📚 Shopping",
      "amount": -600,
      "date": "Sep 11, 16:00",
      "type": "expense",
    },
    {
      "category": "🍕 Food & Dining",
      "amount": -180,
      "date": "Sep 10, 12:00",
      "type": "expense",
    },
    {
      "category": "🎬 Entertainment",
      "amount": -350,
      "date": "Sep 9, 20:00",
      "type": "expense",
    },
    {
      "category": "💊 Healthcare",
      "amount": -400,
      "date": "Sep 8, 11:00",
      "type": "expense",
    },
    {
      "category": "📱 Shopping",
      "amount": -2000,
      "date": "Sep 7, 14:00",
      "type": "expense",
    },
  ];

  // Helper methods
  double get _totalExpenses => _transactions
      .where((t) => t['type'] == 'expense')
      .fold(0.0, (sum, t) => sum + t['amount'].abs());

  double get _totalIncome => _transactions
      .where((t) => t['type'] == 'income')
      .fold(0.0, (sum, t) => sum + t['amount'].abs());

  List<Map<String, dynamic>> get _filteredTransactions {
    var filtered = _transactions.where((transaction) {
      // Search filter
      if (_searchQuery.isNotEmpty) {
        if (!transaction['category'].toString().toLowerCase().contains(
              _searchQuery.toLowerCase(),
            ) &&
            !transaction['date'].toString().toLowerCase().contains(
              _searchQuery.toLowerCase(),
            )) {
          return false;
        }
      }

      // Filter logic
      if (_selectedFilter != "All") {
        switch (_selectedFilter) {
          case "Income":
            if (transaction['type'] != 'income') return false;
            break;
          case "Expenses":
            if (transaction['type'] != 'expense') return false;
            break;
          case "Category":
            // Show all transactions with categories (all transactions)
            break;
          case "Assets":
            // Filter for asset-related transactions
            if (!transaction['category'].toString().contains('🏠') &&
                !transaction['category'].toString().contains('💼') &&
                !transaction['category'].toString().contains('💻')) {
              return false;
            }
            break;
          case "Ledger":
            // Filter for ledger-related transactions (could be all transactions in this context)
            break;
          default:
            // For specific categories, check if category contains the filter text
            if (!transaction['category'].toString().contains(_selectedFilter)) {
              return false;
            }
            break;
        }
      }

      return true;
    }).toList();

    // Sort by date (most recent first)
    filtered.sort((a, b) => b['date'].compareTo(a['date']));
    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text("Transactions"),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddTransactionDialog(),
          ),
          // Monthly period display
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _selectedMonth,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.calendar_month,
                    color: Colors.grey[700],
                    size: 20,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Content
            Expanded(
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (_selectedView == "overview") ...[
                      // 📊 Expenses/Income Overview Card
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedView = "expenses";
                          });
                        },
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Colors.purple, Colors.blue],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        "Expenses",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        "฿${_totalExpenses.toStringAsFixed(2)}",
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 24,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const Icon(
                                    Icons.arrow_forward,
                                    color: Colors.white,
                                    size: 24,
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        "Income",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        "฿${_totalIncome.toStringAsFixed(2)}",
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 24,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        _selectedView = "income";
                                      });
                                    },
                                    child: const Icon(
                                      Icons.arrow_forward,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // 🔍 Search and Filter
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              onChanged: (value) {
                                setState(() {
                                  _searchQuery = value;
                                });
                              },
                              decoration: InputDecoration(
                                hintText: "Search transactions...",
                                prefixIcon: const Icon(Icons.search),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide.none,
                                ),
                                filled: true,
                                fillColor: Colors.grey[100],
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.grey[100],
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: PopupMenuButton<String>(
                              onSelected: (String value) {
                                setState(() {
                                  _selectedFilter = value;
                                });
                              },
                              itemBuilder: (BuildContext context) => [
                                const PopupMenuItem<String>(
                                  value: "All",
                                  child: Text("All"),
                                ),
                                const PopupMenuItem<String>(
                                  value: "Category",
                                  child: Text("Category"),
                                ),
                                const PopupMenuItem<String>(
                                  value: "Assets",
                                  child: Text("Assets"),
                                ),
                                const PopupMenuItem<String>(
                                  value: "Ledger",
                                  child: Text("Ledger"),
                                ),
                                const PopupMenuItem<String>(
                                  value: "Income",
                                  child: Text("Income"),
                                ),
                                const PopupMenuItem<String>(
                                  value: "Expenses",
                                  child: Text("Expenses"),
                                ),
                              ],
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      _selectedFilter,
                                      style: const TextStyle(fontSize: 14),
                                    ),
                                    const SizedBox(width: 4),
                                    const Icon(Icons.filter_list, size: 16),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 20),

                      // 📊 Expenses Donut Chart
                      _buildDonutChartCard("Expenses", _getExpenseData(), () {
                        // Navigate to detailed expenses page
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailedExpensesPage(),
                          ),
                        );
                      }),

                      const SizedBox(height: 20),

                      // 📊 Income Donut Chart
                      _buildDonutChartCard("Income", _getIncomeData(), () {
                        // Navigate to detailed income page
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailedIncomePage(),
                          ),
                        );
                      }),

                      const SizedBox(height: 20),

                      // 📅 Daily Calendar with Toggle
                      _buildCombinedCalendarSection(),

                      const SizedBox(height: 20),

                      // 📊 Monthly Histogram
                      _buildMonthlyHistogramSection(),

                      const SizedBox(height: 20),

                      // 📝 Transaction History
                      const Text(
                        "Monthly Transaction History",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      if (_filteredTransactions.isEmpty)
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(40),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Icon(
                                Icons.receipt_long,
                                size: 64,
                                color: Colors.grey[400],
                              ),
                              const SizedBox(height: 16),
                              Text(
                                "No transactions found",
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey[600],
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                            ],
                          ),
                        )
                      else
                        ..._filteredTransactions
                            .map((transaction) => _transactionItem(transaction))
                            .toList(),
                    ] else if (_selectedView == "expenses") ...[
                      // Expenses View
                      _buildMonthlyView(
                        "Expenses",
                        _filteredTransactions
                            .where((t) => t['type'] == 'expense')
                            .toList(),
                      ),
                    ] else if (_selectedView == "income") ...[
                      // Income View
                      _buildMonthlyView(
                        "Income",
                        _filteredTransactions
                            .where((t) => t['type'] == 'income')
                            .toList(),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDonutChartCard(
    String title,
    List<Map<String, dynamic>> data,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Icon(Icons.arrow_forward, color: Colors.blue[600], size: 24),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                // Donut Chart
                Expanded(
                  flex: 2,
                  child: SizedBox(
                    height: 120,
                    child: PieChart(
                      PieChartData(
                        sectionsSpace: 2,
                        centerSpaceRadius: 30,
                        sections: data.map((item) {
                          final percentage =
                              ((item['amount'] /
                                  data.fold(
                                    0.0,
                                    (sum, item) => sum + item['amount'],
                                  )) *
                              100);
                          return PieChartSectionData(
                            color: item['color'],
                            value: item['amount'],
                            title: percentage > 5
                                ? '${percentage.toStringAsFixed(0)}%'
                                : '',
                            radius: 40,
                            titleStyle: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Legend
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: data.map((item) {
                      final percentage =
                          ((item['amount'] /
                              data.fold(
                                0.0,
                                (sum, item) => sum + item['amount'],
                              )) *
                          100);
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            Container(
                              width: 12,
                              height: 12,
                              decoration: BoxDecoration(
                                color: item['color'],
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                item['category'],
                                style: const TextStyle(fontSize: 12),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Text(
                              '${percentage.toStringAsFixed(1)}%',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMonthlyView(
    String title,
    List<Map<String, dynamic>> transactions,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Back button and title
        Row(
          children: [
            IconButton(
              onPressed: () {
                setState(() {
                  _selectedView = "overview";
                });
              },
              icon: const Icon(Icons.arrow_back),
            ),
            Text(
              "$title - $_selectedMonth",
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // Search bar
        TextField(
          onChanged: (value) {
            setState(() {
              _searchQuery = value;
            });
          },
          decoration: InputDecoration(
            hintText: "Search $title...",
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            filled: true,
            fillColor: Colors.grey[100],
          ),
        ),
        const SizedBox(height: 16),

        // Transactions list
        if (transactions.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(40),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                Icon(Icons.receipt_long, size: 64, color: Colors.grey[400]),
                const SizedBox(height: 16),
                Text(
                  "No $title found",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[600],
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          )
        else
          ...transactions
              .map((transaction) => _transactionItem(transaction))
              .toList(),
      ],
    );
  }

  Widget _transactionItem(Map<String, dynamic> transaction) {
    final isExpense = transaction['type'] == 'expense';
    final amount = transaction['amount'].abs();

    return GestureDetector(
      onTap: () => _showTransactionDetailsDialog(transaction),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isExpense ? Colors.red[100] : Colors.green[100],
                shape: BoxShape.circle,
              ),
              child: Icon(
                isExpense ? Icons.arrow_downward : Icons.arrow_upward,
                color: isExpense ? Colors.red[600] : Colors.green[600],
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    transaction['category'],
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    transaction['date'],
                    style: TextStyle(color: Colors.grey[600], fontSize: 12),
                  ),
                ],
              ),
            ),
            Text(
              "${isExpense ? '-' : '+'}฿${amount.toStringAsFixed(2)}",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: isExpense ? Colors.red[600] : Colors.green[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _getExpenseData() {
    final expenses = _transactions
        .where((t) => t['type'] == 'expense')
        .toList();
    final categories = <String, double>{};

    for (var expense in expenses) {
      final category = expense['category'].toString();
      categories[category] =
          (categories[category] ?? 0) + expense['amount'].abs();
    }

    final colors = [
      Colors.red,
      Colors.orange,
      Colors.purple,
      Colors.blue,
      Colors.green,
      Colors.teal,
    ];
    int colorIndex = 0;

    return categories.entries.map((entry) {
      return {
        'category': entry.key,
        'amount': entry.value,
        'color': colors[colorIndex++ % colors.length],
      };
    }).toList();
  }

  List<Map<String, dynamic>> _getIncomeData() {
    final income = _transactions.where((t) => t['type'] == 'income').toList();
    final categories = <String, double>{};

    for (var item in income) {
      final category = item['category'].toString();
      categories[category] = (categories[category] ?? 0) + item['amount'];
    }

    final colors = [
      Colors.green,
      Colors.blue,
      Colors.purple,
      Colors.orange,
      Colors.teal,
      Colors.indigo,
    ];
    int colorIndex = 0;

    return categories.entries.map((entry) {
      return {
        'category': entry.key,
        'amount': entry.value,
        'color': colors[colorIndex++ % colors.length],
      };
    }).toList();
  }

  // CRUD Operations for Transactions
  void _showAddTransactionDialog() {
    final TextEditingController categoryController = TextEditingController();
    final TextEditingController amountController = TextEditingController();
    final TextEditingController remarkController = TextEditingController();
    String selectedAsset = "Cash";
    String selectedLedger = "Personal";
    String selectedType = "expense";
    DateTime selectedDate = DateTime.now();
    TimeOfDay selectedTime = TimeOfDay.now();

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text("Add Transaction"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Transaction Type
                Row(
                  children: [
                    Expanded(
                      child: RadioListTile<String>(
                        title: const Text("Expense"),
                        value: "expense",
                        groupValue: selectedType,
                        onChanged: (value) {
                          setState(() {
                            selectedType = value!;
                          });
                        },
                      ),
                    ),
                    Expanded(
                      child: RadioListTile<String>(
                        title: const Text("Income"),
                        value: "income",
                        groupValue: selectedType,
                        onChanged: (value) {
                          setState(() {
                            selectedType = value!;
                          });
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Category
                TextField(
                  controller: categoryController,
                  decoration: const InputDecoration(
                    labelText: "Category",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.category),
                  ),
                ),
                const SizedBox(height: 16),
                // Amount
                TextField(
                  controller: amountController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: "Amount",
                    border: OutlineInputBorder(),
                    prefixText: "฿",
                    prefixIcon: Icon(Icons.attach_money),
                  ),
                ),
                const SizedBox(height: 16),
                // Date and Time Row
                Row(
                  children: [
                    Expanded(
                      child: ListTile(
                        title: const Text("Date"),
                        subtitle: Text(selectedDate.toString().split(' ')[0]),
                        trailing: const Icon(Icons.calendar_today),
                        onTap: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: selectedDate,
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                          );
                          if (date != null) {
                            setState(() {
                              selectedDate = date;
                            });
                          }
                        },
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: const Text("Time"),
                        subtitle: Text(selectedTime.format(context)),
                        trailing: const Icon(Icons.access_time),
                        onTap: () async {
                          final time = await showTimePicker(
                            context: context,
                            initialTime: selectedTime,
                          );
                          if (time != null) {
                            setState(() {
                              selectedTime = time;
                            });
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Asset Dropdown
                DropdownButtonFormField<String>(
                  value: selectedAsset,
                  decoration: const InputDecoration(
                    labelText: "Asset",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.account_balance_wallet),
                  ),
                  items:
                      [
                            "Cash",
                            "Credit Card",
                            "Bank Transfer",
                            "Investment Account",
                          ]
                          .map(
                            (asset) => DropdownMenuItem(
                              value: asset,
                              child: Text(asset),
                            ),
                          )
                          .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedAsset = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                // Ledger Dropdown
                DropdownButtonFormField<String>(
                  value: selectedLedger,
                  decoration: const InputDecoration(
                    labelText: "Ledger",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.book),
                  ),
                  items: ["Personal", "Business", "Investment", "Savings"]
                      .map(
                        (ledger) => DropdownMenuItem(
                          value: ledger,
                          child: Text(ledger),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedLedger = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                // Remark
                TextField(
                  controller: remarkController,
                  decoration: const InputDecoration(
                    labelText: "Remark (Good, Bad, etc.)",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.note),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () {
                if (categoryController.text.isEmpty ||
                    amountController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Please fill in all required fields"),
                      backgroundColor: Colors.red,
                    ),
                  );
                  return;
                }

                final transaction = {
                  "category": "📝 ${categoryController.text}",
                  "amount": selectedType == "expense"
                      ? -double.tryParse(amountController.text)!
                      : double.tryParse(amountController.text)!,
                  "date": selectedDate.toString().split(' ')[0],
                  "time": selectedTime.format(context),
                  "asset": selectedAsset,
                  "ledger": selectedLedger,
                  "remark": remarkController.text.isNotEmpty
                      ? remarkController.text
                      : "Good",
                  "type": selectedType,
                };

                setState(() {
                  _transactions.insert(0, transaction);
                });

                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Transaction added successfully!"),
                    backgroundColor: Colors.green,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              child: const Text("Add", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _showEditTransactionDialog(Map<String, dynamic> transaction, int index) {
    final TextEditingController categoryController = TextEditingController(
      text: transaction["category"]
          .toString()
          .replaceAll(RegExp(r'[^\w\s]'), '')
          .trim(),
    );
    final TextEditingController amountController = TextEditingController(
      text: transaction["amount"].abs().toString(),
    );

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text("Edit Transaction"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: categoryController,
                decoration: const InputDecoration(
                  labelText: "Category",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Amount",
                  border: OutlineInputBorder(),
                  prefixText: "฿",
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () {
                if (categoryController.text.isEmpty ||
                    amountController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Please fill in all fields"),
                      backgroundColor: Colors.red,
                    ),
                  );
                  return;
                }

                setState(() {
                  _transactions[index] = {
                    "category": "📝 ${categoryController.text}",
                    "amount": -double.tryParse(amountController.text)!,
                    "date": "Updated",
                    "type": "expense",
                  };
                });

                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Transaction updated successfully!"),
                    backgroundColor: Colors.green,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              child: const Text(
                "Update",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showTransactionDetailsDialog(Map<String, dynamic> transaction) {
    final isExpense = transaction['type'] == 'expense';
    final amount = transaction['amount'].abs();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isExpense ? Colors.red[100] : Colors.green[100],
                shape: BoxShape.circle,
              ),
              child: Icon(
                isExpense ? Icons.arrow_downward : Icons.arrow_upward,
                color: isExpense ? Colors.red[600] : Colors.green[600],
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    transaction['category'],
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    "${isExpense ? '-' : '+'}฿${amount.toStringAsFixed(2)}",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: isExpense ? Colors.red[600] : Colors.green[600],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDetailRow(
                "Date",
                transaction['date'] ?? DateTime.now().toString().split(' ')[0],
              ),
              _buildDetailRow(
                "Time",
                transaction['time'] ??
                    DateTime.now().toString().split(' ')[1].substring(0, 5),
              ),
              _buildDetailRow("Asset", transaction['asset'] ?? "Cash"),
              _buildDetailRow("Ledger", transaction['ledger'] ?? "Default"),
              _buildDetailRow("Remark", transaction['remark'] ?? "Good"),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Close"),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).pop();
              final index = _transactions.indexOf(transaction);
              _showEditTransactionDialog(transaction, index);
            },
            icon: const Icon(Icons.edit, size: 18),
            label: const Text("Edit"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).pop();
              final index = _transactions.indexOf(transaction);
              _showDeleteConfirmationDialog(index);
            },
            icon: const Icon(Icons.delete, size: 18),
            label: const Text("Delete"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 60,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Colors.grey,
              ),
            ),
          ),
          Expanded(child: Text(value, style: const TextStyle(fontSize: 14))),
        ],
      ),
    );
  }

  void _showDeleteConfirmationDialog(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Delete Transaction"),
        content: const Text("Are you sure you want to delete this record?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _transactions.removeAt(index);
              });
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Transaction deleted successfully!"),
                  backgroundColor: Colors.red,
                ),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text("Delete"),
          ),
        ],
      ),
    );
  }

  Widget _buildCombinedCalendarSection() {
    final now = DateTime.now();
    final currentMonth = now.month;
    final currentYear = now.year;
    final daysInMonth = DateTime(currentYear, currentMonth + 1, 0).day;
    final firstDayOfMonth = DateTime(currentYear, currentMonth, 1);
    final firstWeekday = firstDayOfMonth.weekday;

    // Get transactions for selected type
    final typeTransactions = _transactions
        .where((t) => t['type'] == _calendarView)
        .toList();

    // Calculate daily amounts
    Map<int, double> dailyAmounts = {};
    for (var transaction in typeTransactions) {
      try {
        final date = DateTime.parse(transaction['date']);
        if (date.month == currentMonth && date.year == currentYear) {
          final day = date.day;
          dailyAmounts[day] =
              (dailyAmounts[day] ?? 0) + transaction['amount'].abs();
        }
      } catch (e) {
        // Skip invalid dates
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Daily ${_calendarView == 'expense' ? 'Spending' : 'Income'}",
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            // Toggle Switch
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _calendarView = 'expense';
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: _calendarView == 'expense'
                            ? Colors.red
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'Expense',
                        style: TextStyle(
                          color: _calendarView == 'expense'
                              ? Colors.white
                              : Colors.grey[600],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _calendarView = 'income';
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: _calendarView == 'income'
                            ? Colors.green
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'Income',
                        style: TextStyle(
                          color: _calendarView == 'income'
                              ? Colors.white
                              : Colors.grey[600],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              // Calendar header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _getCurrentMonth(),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.chevron_left),
                        onPressed: () {
                          // Previous month logic
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.chevron_right),
                        onPressed: () {
                          // Next month logic
                        },
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Days of week header
              Row(
                children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                    .map(
                      (day) => Expanded(
                        child: Center(
                          child: Text(
                            day,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.grey[600],
                            ),
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
              const SizedBox(height: 8),
              // Calendar grid
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                  childAspectRatio: 1.2,
                ),
                itemCount: firstWeekday + daysInMonth,
                itemBuilder: (context, index) {
                  if (index < firstWeekday) {
                    // Empty cells before first day
                    return Container();
                  }

                  final day = index - firstWeekday + 1;
                  final amount = dailyAmounts[day] ?? 0;
                  final isToday = day == now.day;

                  return GestureDetector(
                    onTap: () =>
                        _showDayDetailsDialog(day, amount, _calendarView),
                    child: Container(
                      margin: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: amount > 0
                            ? (_calendarView == 'expense'
                                  ? Colors.red[50]
                                  : Colors.green[50])
                            : Colors.grey[50],
                        borderRadius: BorderRadius.circular(8),
                        border: isToday
                            ? Border.all(color: Colors.blue, width: 2)
                            : null,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            day.toString(),
                            style: TextStyle(
                              fontWeight: isToday
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                              color: isToday ? Colors.blue : Colors.black,
                            ),
                          ),
                          if (amount > 0) ...[
                            const SizedBox(height: 2),
                            Text(
                              '฿${amount.toStringAsFixed(0)}',
                              style: TextStyle(
                                fontSize: 8,
                                color: _calendarView == 'expense'
                                    ? Colors.red[600]
                                    : Colors.green[600],
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMonthlyHistogramSection() {
    final now = DateTime.now();
    final currentMonth = now.month;
    final currentYear = now.year;

    // Calculate weekly totals
    List<Map<String, dynamic>> weeklyData = [];

    // Get all transactions for current month
    final monthlyTransactions = _transactions.where((t) {
      try {
        final date = DateTime.parse(t['date']);
        return date.month == currentMonth && date.year == currentYear;
      } catch (e) {
        return false;
      }
    }).toList();

    // Group by weeks
    for (int week = 1; week <= 5; week++) {
      final weekStart = (week - 1) * 7 + 1;
      final weekEnd = (week * 7).clamp(
        1,
        DateTime(currentYear, currentMonth + 1, 0).day,
      );

      double weekExpense = 0;
      double weekIncome = 0;

      for (var transaction in monthlyTransactions) {
        try {
          final date = DateTime.parse(transaction['date']);
          if (date.day >= weekStart && date.day <= weekEnd) {
            if (transaction['type'] == 'expense') {
              weekExpense += transaction['amount'].abs();
            } else {
              weekIncome += transaction['amount'].abs();
            }
          }
        } catch (e) {
          // Skip invalid dates
        }
      }

      weeklyData.add({
        'week': 'Week $week',
        'expense': weekExpense,
        'income': weekIncome,
      });
    }

    final maxAmount = weeklyData
        .fold<double>(
          0,
          (max, week) => [
            week['expense'],
            week['income'],
          ].fold<double>(0, (sum, amount) => sum + (amount as double)),
        )
        .clamp(1000, double.infinity);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Monthly Histogram",
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              // Legend
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Colors.red[400],
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text("Expenses", style: TextStyle(fontSize: 12)),
                  const SizedBox(width: 20),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Colors.green[400],
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text("Income", style: TextStyle(fontSize: 12)),
                ],
              ),
              const SizedBox(height: 20),
              // Histogram bars
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: weeklyData.map((week) {
                  final expenseHeight =
                      (week['expense'] as double) / maxAmount * 100;
                  final incomeHeight =
                      (week['income'] as double) / maxAmount * 100;

                  return Column(
                    children: [
                      // Value labels
                      Text(
                        '฿${((week['expense'] as double) + (week['income'] as double)).toStringAsFixed(0)}',
                        style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      // Bars
                      Container(
                        width: 40,
                        height: 120,
                        child: Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            // Income bar (green)
                            Container(
                              width: 15,
                              height: incomeHeight,
                              decoration: BoxDecoration(
                                color: Colors.green[400],
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                            // Expense bar (red)
                            Positioned(
                              left: 20,
                              child: Container(
                                width: 15,
                                height: expenseHeight,
                                decoration: BoxDecoration(
                                  color: Colors.red[400],
                                  borderRadius: BorderRadius.circular(2),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      // Week label
                      Text(
                        week['week'] as String,
                        style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _showDayDetailsDialog(int day, double amount, String type) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("$day ${_getCurrentMonth()}"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "${type == 'expense' ? 'Spending' : 'Income'}: ฿${amount.toStringAsFixed(2)}",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: type == 'expense' ? Colors.red[600] : Colors.green[600],
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _showAddTransactionDialog();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: type == 'expense' ? Colors.red : Colors.green,
              ),
              child: Text(
                "Add ${type == 'expense' ? 'Expense' : 'Income'}",
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Close"),
          ),
        ],
      ),
    );
  }
}
