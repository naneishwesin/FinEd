// lib/pages/budget_management_page.dart
import 'package:flutter/material.dart';


class BudgetManagementPage extends StatefulWidget {
  @override
  _BudgetManagementPageState createState() => _BudgetManagementPageState();
}

class _BudgetManagementPageState extends State<BudgetManagementPage> {
  double _monthlyBudget = 20000.00;
  List<Map<String, dynamic>> _budgetPlans = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text("Budget Management"),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Monthly Budget Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.purple[300]!, Colors.purple[600]!],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Monthly Budget",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "฿${_monthlyBudget.toStringAsFixed(2)}",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Remaining: ฿${_monthlyBudget.toStringAsFixed(2)}",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Budget Plans Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Budget Plans",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.add, color: Colors.white, size: 20),
                    onPressed: () => _showAddBudgetPlanDialog(),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Budget Plans List
            if (_budgetPlans.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(40),
                child: Column(
                  children: [
                    Icon(
                      Icons.account_balance_wallet_outlined,
                      size: 64,
                      color: Colors.grey[400],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "No budget plans set yet",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[600],
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              )
            else
              ..._budgetPlans
                  .map((plan) => _buildBudgetPlanCard(plan))
                  .toList(),

            const SizedBox(height: 24),

            // Budget Tips Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Budget Tips",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  _buildTipItem(
                    Icons.lightbulb_outline,
                    "Set realistic budget limits for each category",
                  ),
                  const SizedBox(height: 12),
                  _buildTipItem(
                    Icons.trending_up,
                    "Review your spending patterns monthly",
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBudgetPlanCard(Map<String, dynamic> plan) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: plan['color'],
              shape: BoxShape.circle,
            ),
            child: Icon(plan['icon'], color: Colors.white, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  plan['category'],
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Budget: ฿${plan['budget'].toStringAsFixed(2)}",
                  style: TextStyle(color: Colors.grey[600], fontSize: 14),
                ),
                const SizedBox(height: 4),
                Text(
                  "Spent: ฿${plan['spent'].toStringAsFixed(2)}",
                  style: TextStyle(
                    color: plan['spent'] > plan['budget']
                        ? Colors.red
                        : Colors.green,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Column(
            children: [
              Text(
                "${((plan['spent'] / plan['budget']) * 100).toStringAsFixed(0)}%",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: plan['spent'] > plan['budget']
                      ? Colors.red
                      : Colors.green,
                ),
              ),
              const SizedBox(height: 4),
              Container(
                width: 60,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(2),
                ),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: (plan['spent'] / plan['budget']).clamp(0.0, 1.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: plan['spent'] > plan['budget']
                          ? Colors.red
                          : Colors.green,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTipItem(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: Colors.blue[600], size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(fontSize: 14, color: Colors.grey[700]),
          ),
        ),
      ],
    );
  }

  void _showAddBudgetPlanDialog() {
    final TextEditingController categoryController = TextEditingController();
    final TextEditingController budgetController = TextEditingController();
    IconData selectedIcon = Icons.category;
    Color selectedColor = Colors.blue;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text("Add Budget Plan"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Category Name
                    TextField(
                      controller: categoryController,
                      decoration: const InputDecoration(
                        labelText: "Category",
                        hintText: "e.g., Food, Transport, Entertainment",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Budget Amount
                    TextField(
                      controller: budgetController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: "Budget Amount",
                        hintText: "Enter amount in ฿",
                        border: OutlineInputBorder(),
                        prefixText: "฿",
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Icon Selection
                    const Text("Select Icon:"),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        _buildIconOption(Icons.restaurant, selectedIcon, () {
                          setDialogState(() {
                            selectedIcon = Icons.restaurant;
                          });
                        }),
                        _buildIconOption(
                          Icons.directions_car,
                          selectedIcon,
                          () {
                            setDialogState(() {
                              selectedIcon = Icons.directions_car;
                            });
                          },
                        ),
                        _buildIconOption(Icons.shopping_bag, selectedIcon, () {
                          setDialogState(() {
                            selectedIcon = Icons.shopping_bag;
                          });
                        }),
                        _buildIconOption(Icons.movie, selectedIcon, () {
                          setDialogState(() {
                            selectedIcon = Icons.movie;
                          });
                        }),
                        _buildIconOption(Icons.school, selectedIcon, () {
                          setDialogState(() {
                            selectedIcon = Icons.school;
                          });
                        }),
                        _buildIconOption(
                          Icons.health_and_safety,
                          selectedIcon,
                          () {
                            setDialogState(() {
                              selectedIcon = Icons.health_and_safety;
                            });
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Color Selection
                    const Text("Select Color:"),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        _buildColorOption(Colors.blue, selectedColor, () {
                          setDialogState(() {
                            selectedColor = Colors.blue;
                          });
                        }),
                        _buildColorOption(Colors.green, selectedColor, () {
                          setDialogState(() {
                            selectedColor = Colors.green;
                          });
                        }),
                        _buildColorOption(Colors.orange, selectedColor, () {
                          setDialogState(() {
                            selectedColor = Colors.orange;
                          });
                        }),
                        _buildColorOption(Colors.red, selectedColor, () {
                          setDialogState(() {
                            selectedColor = Colors.red;
                          });
                        }),
                        _buildColorOption(Colors.purple, selectedColor, () {
                          setDialogState(() {
                            selectedColor = Colors.purple;
                          });
                        }),
                        _buildColorOption(Colors.teal, selectedColor, () {
                          setDialogState(() {
                            selectedColor = Colors.teal;
                          });
                        }),
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (categoryController.text.isNotEmpty &&
                        budgetController.text.isNotEmpty) {
                      final budget = double.tryParse(budgetController.text);
                      if (budget != null && budget > 0) {
                        setState(() {
                          _budgetPlans.add({
                            'category': categoryController.text,
                            'budget': budget,
                            'spent': 0.0,
                            'icon': selectedIcon,
                            'color': selectedColor,
                          });
                        });
                        Navigator.of(context).pop();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text("Budget plan added successfully!"),
                            backgroundColor: Colors.green,
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text("Please enter a valid budget amount"),
                            backgroundColor: Colors.red,
                          ),
                        );
                      }
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Please fill in all fields"),
                          backgroundColor: Colors.red,
                        ),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[600],
                    foregroundColor: Colors.white,
                  ),
                  child: const Text("Add Plan"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildIconOption(
    IconData icon,
    IconData selectedIcon,
    VoidCallback onTap,
  ) {
    final isSelected = icon == selectedIcon;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: isSelected ? Colors.blue : Colors.grey[200],
          shape: BoxShape.circle,
        ),
        child: Icon(
          icon,
          color: isSelected ? Colors.white : Colors.grey[600],
          size: 20,
        ),
      ),
    );
  }

  Widget _buildColorOption(
    Color color,
    Color selectedColor,
    VoidCallback onTap,
  ) {
    final isSelected = color == selectedColor;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: isSelected ? Colors.black : Colors.transparent,
            width: 2,
          ),
        ),
      ),
    );
  }
}
