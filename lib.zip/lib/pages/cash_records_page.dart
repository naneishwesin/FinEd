// lib/pages/cash_records_page.dart
import 'package:flutter/material.dart';

class CashRecordsPage extends StatefulWidget {
  final List<Map<String, dynamic>> allTransactions;

  const CashRecordsPage({Key? key, required this.allTransactions})
    : super(key: key);

  @override
  _CashRecordsPageState createState() => _CashRecordsPageState();
}

class _CashRecordsPageState extends State<CashRecordsPage> {
  String _searchQuery = "";

  List<Map<String, dynamic>> get _cashTransactions {
    // Filter transactions that use Cash as payment method
    return widget.allTransactions.where((transaction) {
      return transaction['asset'] == 'Cash' || transaction['payment'] == 'Cash';
    }).toList();
  }

  List<Map<String, dynamic>> get _filteredTransactions {
    return _cashTransactions.where((transaction) {
      if (_searchQuery.isNotEmpty) {
        return transaction['category'].toString().toLowerCase().contains(
              _searchQuery.toLowerCase(),
            ) ||
            transaction['date'].toString().toLowerCase().contains(
              _searchQuery.toLowerCase(),
            );
      }
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text("Cash Records"),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search bar
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value;
                  });
                },
                decoration: InputDecoration(
                  hintText: "Search cash transactions...",
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.grey[100],
                ),
              ),
            ),

            // Transaction list
            Expanded(
              child: _filteredTransactions.isEmpty
                  ? Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(40),
                      child: Column(
                        children: [
                          Icon(
                            Icons.receipt_long,
                            size: 64,
                            color: Colors.grey[400],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            "No cash transactions found",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey[600],
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _filteredTransactions.length,
                      itemBuilder: (context, index) {
                        final transaction = _filteredTransactions[index];
                        return _transactionItem(transaction);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _transactionItem(Map<String, dynamic> transaction) {
    final isExpense = transaction['type'] == 'expense';
    final amount = transaction['amount'].abs();

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isExpense ? Colors.red[100] : Colors.green[100],
              shape: BoxShape.circle,
            ),
            child: Icon(
              isExpense ? Icons.arrow_downward : Icons.arrow_upward,
              color: isExpense ? Colors.red[600] : Colors.green[600],
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  transaction['category'],
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  transaction['date'],
                  style: TextStyle(color: Colors.grey[600], fontSize: 12),
                ),
                const SizedBox(height: 2),
                Text(
                  "Cash Payment",
                  style: TextStyle(color: Colors.blue[600], fontSize: 12),
                ),
              ],
            ),
          ),
          Text(
            "${isExpense ? '-' : '+'}฿${amount.toStringAsFixed(2)}",
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: isExpense ? Colors.red[600] : Colors.green[600],
            ),
          ),
          const SizedBox(width: 8),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'edit') {
                _showEditTransactionDialog(transaction);
              } else if (value == 'delete') {
                _showDeleteConfirmationDialog(transaction);
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit, size: 16),
                    SizedBox(width: 8),
                    Text('Edit'),
                  ],
                ),
              ),
              const PopupMenuItem<String>(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, size: 16, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
            child: Icon(Icons.more_vert, color: Colors.grey[600], size: 20),
          ),
        ],
      ),
    );
  }

  void _showEditTransactionDialog(Map<String, dynamic> transaction) {
    final TextEditingController categoryController = TextEditingController(
      text: transaction['category'],
    );
    final TextEditingController amountController = TextEditingController(
      text: transaction['amount'].abs().toString(),
    );
    final TextEditingController remarkController = TextEditingController(
      text: transaction['remark'] ?? '',
    );
    String selectedType = transaction['type'];
    String selectedLedger = transaction['ledger'] ?? 'Personal';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Edit Cash Transaction"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Type Selection
              Row(
                children: [
                  Expanded(
                    child: RadioListTile<String>(
                      title: const Text("Expense"),
                      value: "expense",
                      groupValue: selectedType,
                      onChanged: (value) {
                        setState(() {
                          selectedType = value!;
                        });
                      },
                    ),
                  ),
                  Expanded(
                    child: RadioListTile<String>(
                      title: const Text("Income"),
                      value: "income",
                      groupValue: selectedType,
                      onChanged: (value) {
                        setState(() {
                          selectedType = value!;
                        });
                      },
                    ),
                  ),
                ],
              ),

              // Category
              TextField(
                controller: categoryController,
                decoration: const InputDecoration(
                  labelText: "Category",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),

              // Amount
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Amount",
                  border: OutlineInputBorder(),
                  prefixText: "฿",
                ),
              ),
              const SizedBox(height: 16),

              // Asset (fixed to Cash)
              TextField(
                readOnly: true,
                decoration: const InputDecoration(
                  labelText: "Asset",
                  border: OutlineInputBorder(),
                  hintText: "Cash",
                ),
              ),
              const SizedBox(height: 16),

              // Ledger
              DropdownButtonFormField<String>(
                value: selectedLedger,
                decoration: const InputDecoration(
                  labelText: "Ledger",
                  border: OutlineInputBorder(),
                ),
                items: ['Personal', 'Work', 'Business', 'Family'].map((ledger) {
                  return DropdownMenuItem(value: ledger, child: Text(ledger));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedLedger = value!;
                  });
                },
              ),
              const SizedBox(height: 16),

              // Remark
              TextField(
                controller: remarkController,
                decoration: const InputDecoration(
                  labelText: "Remark",
                  border: OutlineInputBorder(),
                ),
                maxLines: 2,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              final amount = double.tryParse(amountController.text);
              if (amount != null &&
                  amount > 0 &&
                  categoryController.text.isNotEmpty) {
                // Update the transaction (in a real app, you'd save this to your data store)
                setState(() {
                  // Update the transaction in the list
                  final index = widget.allTransactions.indexWhere(
                    (t) => t == transaction,
                  );
                  if (index != -1) {
                    widget.allTransactions[index] = {
                      ...transaction,
                      'category': categoryController.text,
                      'amount': selectedType == 'expense' ? -amount : amount,
                      'type': selectedType,
                      'asset': 'Cash',
                      'ledger': selectedLedger,
                      'remark': remarkController.text,
                    };
                  }
                });
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Transaction updated successfully"),
                    backgroundColor: Colors.green,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Please fill in all required fields"),
                    backgroundColor: Colors.red,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            child: const Text("Save"),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmationDialog(Map<String, dynamic> transaction) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Delete Transaction"),
        content: Text(
          "Are you sure you want to delete this ${transaction['type']} transaction for ฿${transaction['amount'].abs().toStringAsFixed(2)}?",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                widget.allTransactions.remove(transaction);
              });
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Transaction deleted successfully"),
                  backgroundColor: Colors.red,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text("Delete"),
          ),
        ],
      ),
    );
  }
}
