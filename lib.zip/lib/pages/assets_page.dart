// lib/pages/assets_page.dart
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import 'cash_records_page.dart';

class AssetsPage extends StatefulWidget {
  @override
  _AssetsPageState createState() => _AssetsPageState();
}

class _AssetsPageState extends State<AssetsPage> {
  String _selectedChart = "Assets"; // "Assets" or "Liabilities"
  String _selectedTimePeriod = "All Time";

  // Sample data
  final double _totalAssets = 85000;
  final double _totalLiabilities = 25000;
  final double _cashAmount = 15000;

  // Sample transaction data for cash records
  final List<Map<String, dynamic>> _sampleTransactions = [
    {
      "category": "🍕 Food & Dining",
      "amount": -450,
      "date": DateTime.now()
          .subtract(const Duration(days: 1))
          .toString()
          .split(' ')[0],
      "time": "12:00",
      "asset": "Cash",
      "payment": "Cash",
      "ledger": "Personal",
      "remark": "Good",
      "type": "expense",
    },
    {
      "category": "🚗 Transportation",
      "amount": -320,
      "date": DateTime.now()
          .subtract(const Duration(days: 3))
          .toString()
          .split(' ')[0],
      "time": "09:00",
      "asset": "Cash",
      "payment": "Cash",
      "ledger": "Personal",
      "remark": "Good",
      "type": "expense",
    },
    {
      "category": "💼 Salary",
      "amount": 25000,
      "date": DateTime.now()
          .subtract(const Duration(days: 7))
          .toString()
          .split(' ')[0],
      "time": "09:00",
      "asset": "Cash",
      "payment": "Cash",
      "ledger": "Personal",
      "remark": "Good",
      "type": "income",
    },
    {
      "category": "🏪 Coffee",
      "amount": -120,
      "date": DateTime.now().toString().split(' ')[0],
      "time": "08:15",
      "asset": "Cash",
      "payment": "Cash",
      "ledger": "Personal",
      "remark": "Morning coffee",
      "type": "expense",
    },
    {
      "category": "💳 Freelance",
      "amount": 5000,
      "date": DateTime.now()
          .subtract(const Duration(days: 2))
          .toString()
          .split(' ')[0],
      "time": "16:00",
      "asset": "Cash",
      "payment": "Cash",
      "ledger": "Work",
      "remark": "Freelance project",
      "type": "income",
    },
    {
      "category": "🎬 Movies",
      "amount": -350,
      "date": DateTime.now()
          .subtract(const Duration(days: 4))
          .toString()
          .split(' ')[0],
      "time": "19:30",
      "asset": "Cash",
      "payment": "Cash",
      "ledger": "Personal",
      "remark": "Cinema ticket",
      "type": "expense",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text("Assets"),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddAssetDialog(),
          ),
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Section 1: Assets and Liabilities Cards
              Row(
                children: [
                  Expanded(
                    child: _buildAmountCard(
                      "Assets",
                      _totalAssets,
                      Colors.green,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildAmountCard(
                      "Liabilities",
                      _totalLiabilities,
                      Colors.red,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // Section 2: Trending Chart
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Trending Chart",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Row(
                          children: [
                            _buildChartButton(
                              "Assets",
                              _selectedChart == "Assets",
                            ),
                            const SizedBox(width: 8),
                            _buildChartButton(
                              "Liabilities",
                              _selectedChart == "Liabilities",
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Time Period Filter
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 12,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.grey[100],
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.grey[300]!),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _selectedTimePeriod,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                PopupMenuButton<String>(
                                  onSelected: (String value) {
                                    setState(() {
                                      _selectedTimePeriod = value;
                                    });
                                  },
                                  itemBuilder: (BuildContext context) => [
                                    const PopupMenuItem<String>(
                                      value: "Last Month",
                                      child: Text("Last Month"),
                                    ),
                                    const PopupMenuItem<String>(
                                      value: "Last Week",
                                      child: Text("Last Week"),
                                    ),
                                    const PopupMenuItem<String>(
                                      value: "Last Quarter",
                                      child: Text("Last Quarter"),
                                    ),
                                    const PopupMenuItem<String>(
                                      value: "Last Year",
                                      child: Text("Last Year"),
                                    ),
                                    const PopupMenuItem<String>(
                                      value: "All Time",
                                      child: Text("All Time"),
                                    ),
                                  ],
                                  child: Icon(
                                    Icons.filter_list,
                                    color: Colors.grey[600],
                                    size: 20,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Chart
                    SizedBox(
                      height: 200,
                      child: LineChart(
                        LineChartData(
                          gridData: FlGridData(show: false),
                          titlesData: FlTitlesData(
                            leftTitles: AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            topTitles: AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            rightTitles: AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: (value, meta) {
                                  const months = [
                                    'Jan',
                                    'Feb',
                                    'Mar',
                                    'Apr',
                                    'May',
                                    'Jun',
                                  ];
                                  if (value.toInt() >= 0 &&
                                      value.toInt() < months.length) {
                                    return Text(months[value.toInt()]);
                                  }
                                  return const Text('');
                                },
                              ),
                            ),
                          ),
                          borderData: FlBorderData(show: false),
                          lineBarsData: [
                            LineChartBarData(
                              spots: _getChartData(),
                              isCurved: true,
                              color: _selectedChart == "Assets"
                                  ? Colors.green
                                  : Colors.red,
                              barWidth: 3,
                              isStrokeCapRound: true,
                              dotData: FlDotData(show: false),
                              belowBarData: BarAreaData(
                                show: true,
                                color:
                                    (_selectedChart == "Assets"
                                            ? Colors.green
                                            : Colors.red)
                                        .withOpacity(0.1),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Section 3: Cash Card
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          CashRecordsPage(allTransactions: _sampleTransactions),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Colors.blue, Colors.purple],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.account_balance_wallet,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Cash",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "฿${_cashAmount.toStringAsFixed(2)}",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(
                        Icons.arrow_forward,
                        color: Colors.white,
                        size: 24,
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Section 4: Assets Donut Chart
              _buildDonutChartCard("Assets", _getAssetsData(), Colors.green),

              const SizedBox(height: 20),

              // Section 5: Liabilities Donut Chart
              _buildDonutChartCard(
                "Liabilities",
                _getLiabilitiesData(),
                Colors.red,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAmountCard(String title, double amount, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "฿${amount.toStringAsFixed(2)}",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChartButton(String title, bool isSelected) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedChart = title;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? (title == "Assets" ? Colors.green : Colors.red)
              : Colors.grey[200],
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          title,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey[700],
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildDonutChartCard(
    String title,
    List<Map<String, dynamic>> data,
    Color primaryColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: primaryColor,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              // Donut Chart
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 120,
                  child: PieChart(
                    PieChartData(
                      sectionsSpace: 2,
                      centerSpaceRadius: 30,
                      sections: data.map((item) {
                        final percentage =
                            ((item['amount'] /
                                data.fold(
                                  0.0,
                                  (sum, item) => sum + item['amount'],
                                )) *
                            100);
                        return PieChartSectionData(
                          color: item['color'],
                          value: item['amount'],
                          title: percentage > 5
                              ? '${percentage.toStringAsFixed(0)}%'
                              : '',
                          radius: 40,
                          titleStyle: const TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              // Legend
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: data.map((item) {
                    final percentage =
                        ((item['amount'] /
                            data.fold(
                              0.0,
                              (sum, item) => sum + item['amount'],
                            )) *
                        100);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        children: [
                          Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: item['color'],
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              item['category'],
                              style: const TextStyle(fontSize: 12),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Text(
                            '${percentage.toStringAsFixed(1)}%',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<FlSpot> _getChartData() {
    // Sample data for trending chart
    if (_selectedChart == "Assets") {
      return [
        const FlSpot(0, 70000),
        const FlSpot(1, 72000),
        const FlSpot(2, 75000),
        const FlSpot(3, 78000),
        const FlSpot(4, 82000),
        const FlSpot(5, 85000),
      ];
    } else {
      return [
        const FlSpot(0, 28000),
        const FlSpot(1, 27000),
        const FlSpot(2, 26000),
        const FlSpot(3, 25000),
        const FlSpot(4, 25000),
        const FlSpot(5, 25000),
      ];
    }
  }

  List<Map<String, dynamic>> _getAssetsData() {
    return [
      {'category': '🏠 Real Estate', 'amount': 50000.0, 'color': Colors.blue},
      {'category': '💼 Investments', 'amount': 20000.0, 'color': Colors.green},
      {'category': '🚗 Vehicles', 'amount': 15000.0, 'color': Colors.orange},
    ];
  }

  List<Map<String, dynamic>> _getLiabilitiesData() {
    return [
      {'category': '🏠 Mortgage', 'amount': 15000.0, 'color': Colors.red},
      {'category': '💳 Credit Cards', 'amount': 8000.0, 'color': Colors.pink},
      {'category': '🚗 Car Loan', 'amount': 2000.0, 'color': Colors.deepOrange},
    ];
  }

  // CRUD Operations for Assets
  void _showAddAssetDialog() {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController amountController = TextEditingController();
    String selectedType = 'asset';
    Color selectedColor = Colors.blue;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text("Add Asset/Liability"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Type Selection
                Row(
                  children: [
                    Expanded(
                      child: RadioListTile<String>(
                        title: const Text('Asset'),
                        value: 'asset',
                        groupValue: selectedType,
                        onChanged: (value) =>
                            setState(() => selectedType = value!),
                      ),
                    ),
                    Expanded(
                      child: RadioListTile<String>(
                        title: const Text('Liability'),
                        value: 'liability',
                        groupValue: selectedType,
                        onChanged: (value) =>
                            setState(() => selectedType = value!),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Name
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: "Name",
                    border: OutlineInputBorder(),
                    hintText: "e.g., House, Car, Credit Card",
                  ),
                ),
                const SizedBox(height: 16),

                // Amount
                TextField(
                  controller: amountController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: "Amount",
                    border: OutlineInputBorder(),
                    prefixText: "฿",
                  ),
                ),
                const SizedBox(height: 16),

                // Color Selection
                Row(
                  children: [
                    const Text("Color: "),
                    GestureDetector(
                      onTap: () => _showColorPicker(
                        setState,
                        (color) => selectedColor = color,
                      ),
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: selectedColor,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.grey),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isEmpty ||
                    amountController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Please fill in all fields"),
                      backgroundColor: Colors.red,
                    ),
                  );
                  return;
                }

                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      "${selectedType == 'asset' ? 'Asset' : 'Liability'} '${nameController.text}' added!",
                    ),
                    backgroundColor: Colors.green,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              child: const Text("Add", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _showColorPicker(StateSetter setState, Function(Color) onColorSelected) {
    final List<Color> colors = [
      Colors.red,
      Colors.pink,
      Colors.purple,
      Colors.deepPurple,
      Colors.indigo,
      Colors.blue,
      Colors.lightBlue,
      Colors.cyan,
      Colors.teal,
      Colors.green,
      Colors.lightGreen,
      Colors.lime,
      Colors.yellow,
      Colors.amber,
      Colors.orange,
      Colors.deepOrange,
      Colors.brown,
      Colors.grey,
      Colors.blueGrey,
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Select Color"),
        content: SingleChildScrollView(
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: colors.map((color) {
              return GestureDetector(
                onTap: () {
                  onColorSelected(color);
                  Navigator.of(context).pop();
                },
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.grey[300]!),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  void _showFilterDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Select Time Period"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text("Last Month"),
              onTap: () {
                setState(() {
                  _selectedTimePeriod = "Last Month";
                });
                Navigator.of(context).pop();
              },
            ),
            ListTile(
              title: const Text("Last Week"),
              onTap: () {
                setState(() {
                  _selectedTimePeriod = "Last Week";
                });
                Navigator.of(context).pop();
              },
            ),
            ListTile(
              title: const Text("All Time"),
              onTap: () {
                setState(() {
                  _selectedTimePeriod = "All Time";
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        ),
      ),
    );
  }
}
