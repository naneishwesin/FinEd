import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'main_app.dart';
import 'pages/welcome_onboarding_page.dart';
import 'services/data_service.dart';
import 'services/notification_service.dart';
import 'services/theme_service.dart';
import 'services/tutorial_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DataService.init();
  await TutorialService.init();
  await NotificationService.init();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ThemeService()..initializeTheme(),
      child: Consumer<ThemeService>(
        builder: (context, themeService, child) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Expense Tracker',
            theme: themeService.lightTheme,
            darkTheme: themeService.darkTheme,
            themeMode: themeService.themeMode,
            home: DataService.isOnboardingCompleted()
                ? MainApp()
                : WelcomeOnboardingPage(),
          );
        },
      ),
    );
  }
}
