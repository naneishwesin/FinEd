// lib/services/tutorial_service.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TutorialService {
  static SharedPreferences? _prefs;

  // Initialize SharedPreferences
  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Tutorial completion status
  static Future<void> markTutorialCompleted(String tutorialId) async {
    await _prefs?.setBool('tutorial_$tutorialId', true);
  }

  static bool isTutorialCompleted(String tutorialId) {
    return _prefs?.getBool('tutorial_$tutorialId') ?? false;
  }

  static Future<void> resetAllTutorials() async {
    final keys = _prefs?.getKeys() ?? <String>{};
    for (final key in keys) {
      if (key.startsWith('tutorial_')) {
        await _prefs?.remove(key);
      }
    }
  }

  // Tooltip preferences
  static Future<void> setTooltipsEnabled(bool enabled) async {
    await _prefs?.setBool('tooltips_enabled', enabled);
  }

  static bool areTooltipsEnabled() {
    return _prefs?.getBool('tooltips_enabled') ?? true;
  }
}

// Tooltip widget with positioning
class TooltipOverlay extends StatefulWidget {
  final Widget child;
  final String message;
  final String? tutorialId;
  final GlobalKey targetKey;
  final TooltipPosition position;
  final Duration delay;
  final bool showOnce;

  const TooltipOverlay({
    Key? key,
    required this.child,
    required this.message,
    required this.targetKey,
    this.tutorialId,
    this.position = TooltipPosition.bottom,
    this.delay = const Duration(milliseconds: 500),
    this.showOnce = true,
  }) : super(key: key);

  @override
  State<TooltipOverlay> createState() => _TooltipOverlayState();
}

class _TooltipOverlayState extends State<TooltipOverlay>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  bool _showTooltip = false;
  Offset _tooltipPosition = Offset.zero;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, -0.5), end: Offset.zero).animate(
          CurvedAnimation(
            parent: _animationController,
            curve: Curves.easeOutCubic,
          ),
        );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _showTooltipIfNeeded();
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _showTooltipIfNeeded() {
    if (widget.showOnce && widget.tutorialId != null) {
      if (TutorialService.isTutorialCompleted(widget.tutorialId!)) {
        return;
      }
    }

    if (!TutorialService.areTooltipsEnabled()) {
      return;
    }

    Future.delayed(widget.delay, () {
      if (mounted) {
        _calculatePosition();
        setState(() {
          _showTooltip = true;
        });
        _animationController.forward();
      }
    });
  }

  void _calculatePosition() {
    final RenderBox? renderBox =
        widget.targetKey.currentContext?.findRenderObject() as RenderBox?;
    if (renderBox == null) return;

    final RenderBox overlay =
        Overlay.of(context).context.findRenderObject() as RenderBox;

    final targetPosition = renderBox.localToGlobal(Offset.zero);
    final targetSize = renderBox.size;
    final overlaySize = overlay.size;

    Offset position;
    switch (widget.position) {
      case TooltipPosition.top:
        position = Offset(
          targetPosition.dx + (targetSize.width / 2) - 100,
          targetPosition.dy - 60,
        );
        break;
      case TooltipPosition.bottom:
        position = Offset(
          targetPosition.dx + (targetSize.width / 2) - 100,
          targetPosition.dy + targetSize.height + 10,
        );
        break;
      case TooltipPosition.left:
        position = Offset(
          targetPosition.dx - 220,
          targetPosition.dy + (targetSize.height / 2) - 20,
        );
        break;
      case TooltipPosition.right:
        position = Offset(
          targetPosition.dx + targetSize.width + 10,
          targetPosition.dy + (targetSize.height / 2) - 20,
        );
        break;
    }

    // Ensure tooltip stays within screen bounds
    position = Offset(
      position.dx.clamp(10, overlaySize.width - 210),
      position.dy.clamp(10, overlaySize.height - 60),
    );

    _tooltipPosition = position;
  }

  void _hideTooltip() {
    _animationController.reverse().then((_) {
      if (mounted) {
        setState(() {
          _showTooltip = false;
        });
      }
    });

    if (widget.tutorialId != null) {
      TutorialService.markTutorialCompleted(widget.tutorialId!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        if (_showTooltip)
          Positioned.fill(
            child: GestureDetector(
              onTap: _hideTooltip,
              child: Container(
                color: Colors.transparent,
                child: Stack(
                  children: [
                    // Dark overlay
                    Container(color: Colors.black.withOpacity(0.3)),
                    // Tooltip
                    Positioned(
                      left: _tooltipPosition.dx,
                      top: _tooltipPosition.dy,
                      child: AnimatedBuilder(
                        animation: _animationController,
                        builder: (context, child) {
                          return FadeTransition(
                            opacity: _fadeAnimation,
                            child: SlideTransition(
                              position: _slideAnimation,
                              child: Container(
                                width: 200,
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 8,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      widget.message,
                                      style: const TextStyle(
                                        color: Colors.black87,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        TextButton(
                                          onPressed: _hideTooltip,
                                          style: TextButton.styleFrom(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 4,
                                            ),
                                            minimumSize: Size.zero,
                                            tapTargetSize: MaterialTapTargetSize
                                                .shrinkWrap,
                                          ),
                                          child: const Text(
                                            'Got it',
                                            style: TextStyle(
                                              color: Colors.blue,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}

enum TooltipPosition { top, bottom, left, right }
