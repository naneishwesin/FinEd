// lib/services/chart_service.dart
import 'dart:math';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import 'data_service.dart';

class ChartService {
  // Generate sample data for charts
  static List<FlSpot> generateLineChartData(
    int days,
    double baseValue,
    double volatility,
  ) {
    final List<FlSpot> spots = [];
    final random = Random();
    double currentValue = baseValue;

    for (int i = 0; i < days; i++) {
      // Add some trend and randomness
      double change = (random.nextDouble() - 0.5) * volatility;
      currentValue += change;
      currentValue = max(currentValue, 0); // Ensure non-negative values

      spots.add(FlSpot(i.toDouble(), currentValue));
    }

    return spots;
  }

  // Generate pie chart data
  static List<PieChartSectionData> generatePieChartData(
    Map<String, double> data,
    List<Color> colors,
    double radius,
  ) {
    final List<PieChartSectionData> sections = [];
    final total = data.values.fold(0.0, (sum, value) => sum + value);

    int colorIndex = 0;
    data.forEach((category, value) {
      if (value > 0) {
        final percentage = (value / total) * 100;
        sections.add(
          PieChartSectionData(
            color: colors[colorIndex % colors.length],
            value: value,
            title: '${percentage.toStringAsFixed(1)}%',
            radius: radius,
            titleStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            titlePositionPercentageOffset: 0.6,
          ),
        );
        colorIndex++;
      }
    });

    return sections;
  }

  // Generate bar chart data
  static List<BarChartGroupData> generateBarChartData(
    Map<String, double> data,
    Color color,
  ) {
    final List<BarChartGroupData> groups = [];
    int index = 0;

    data.forEach((label, value) {
      groups.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: value,
              color: color,
              width: 20,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(4),
              ),
            ),
          ],
          showingTooltipIndicators: [0],
        ),
      );
      index++;
    });

    return groups;
  }

  // Get expense categories data
  static Map<String, double> getExpenseCategoriesData() {
    // This would typically come from your data service
    return {
      'Food': 2500.0,
      'Transport': 1200.0,
      'Entertainment': 800.0,
      'Shopping': 1500.0,
      'Bills': 3000.0,
      'Other': 500.0,
    };
  }

  // Get income sources data
  static Map<String, double> getIncomeSourcesData() {
    return {
      'Salary': 15000.0,
      'Freelance': 3000.0,
      'Investment': 800.0,
      'Other': 200.0,
    };
  }

  // Get monthly spending trend
  static List<FlSpot> getMonthlySpendingTrend() {
    return generateLineChartData(30, 5000, 500);
  }

  // Get savings progress
  static List<FlSpot> getSavingsProgress() {
    return generateLineChartData(12, 1000, 200);
  }

  // Get budget vs actual spending
  static List<BarChartGroupData> getBudgetVsActualData() {
    return [
      BarChartGroupData(
        x: 0,
        barRods: [
          BarChartRodData(toY: 5000, color: Colors.blue[300]!),
          BarChartRodData(toY: 4200, color: Colors.green[400]!),
        ],
        showingTooltipIndicators: [0, 1],
      ),
      BarChartGroupData(
        x: 1,
        barRods: [
          BarChartRodData(toY: 3000, color: Colors.blue[300]!),
          BarChartRodData(toY: 2800, color: Colors.green[400]!),
        ],
        showingTooltipIndicators: [0, 1],
      ),
      BarChartGroupData(
        x: 2,
        barRods: [
          BarChartRodData(toY: 2000, color: Colors.blue[300]!),
          BarChartRodData(toY: 2100, color: Colors.red[400]!),
        ],
        showingTooltipIndicators: [0, 1],
      ),
    ];
  }

  // Get expense trend by category
  static Map<String, List<FlSpot>> getExpenseTrendByCategory() {
    return {
      'Food': generateLineChartData(7, 100, 20),
      'Transport': generateLineChartData(7, 50, 10),
      'Entertainment': generateLineChartData(7, 30, 15),
    };
  }

  // Get financial health score
  static double getFinancialHealthScore() {
    final balance = DataService.getCurrentBalance();
    final income = DataService.getIncome();
    final expenses = DataService.getExpenses();

    if (income == 0) return 0.0;

    final savingsRate = (income - expenses) / income;
    final balanceRatio =
        balance / (income * 3); // 3 months of income as emergency fund

    return ((savingsRate * 0.6) + (balanceRatio * 0.4)) * 100;
  }

  // Get spending insights
  static List<String> getSpendingInsights() {
    final insights = <String>[];
    final expenses = DataService.getExpenses();
    final income = DataService.getIncome();

    if (expenses > income * 0.8) {
      insights.add(
        'You\'re spending more than 80% of your income. Consider reducing expenses.',
      );
    }

    if (expenses > income) {
      insights.add(
        'You\'re spending more than you earn. This is unsustainable long-term.',
      );
    } else if (expenses < income * 0.5) {
      insights.add('Great job! You\'re saving more than 50% of your income.');
    }

    return insights;
  }

  // Get color palette for charts
  static List<Color> getChartColors() {
    return [
      Colors.blue[400]!,
      Colors.green[400]!,
      Colors.orange[400]!,
      Colors.purple[400]!,
      Colors.red[400]!,
      Colors.teal[400]!,
      Colors.pink[400]!,
      Colors.indigo[400]!,
      Colors.amber[400]!,
      Colors.cyan[400]!,
    ];
  }

  // Get gradient colors
  static List<Color> getGradientColors() {
    return [Colors.blue[400]!, Colors.blue[600]!];
  }

  // Format currency for display
  static String formatCurrency(double amount, String currency) {
    String symbol;
    switch (currency) {
      case 'USD':
        symbol = '\$';
        break;
      case 'EUR':
        symbol = '€';
        break;
      case 'GBP':
        symbol = '£';
        break;
      case 'JPY':
        symbol = '¥';
        break;
      case 'THB':
      default:
        symbol = '฿';
        break;
    }

    return '$symbol${amount.toStringAsFixed(2)}';
  }

  // Get chart tooltip
  static Widget getTooltip(String title, double value, String currency) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.grey[800],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        '$title\n${formatCurrency(value, currency)}',
        style: const TextStyle(color: Colors.white, fontSize: 12),
      ),
    );
  }
}
