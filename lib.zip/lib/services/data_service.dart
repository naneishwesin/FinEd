// lib/services/data_service.dart
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class DataService {
  static SharedPreferences? _prefs;

  // Initialize SharedPreferences
  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // User Profile Data
  static Future<void> saveUserProfile(Map<String, dynamic> profile) async {
    await _prefs?.setString('user_profile', jsonEncode(profile));
  }

  static Map<String, dynamic>? getUserProfile() {
    final profileString = _prefs?.getString('user_profile');
    if (profileString != null) {
      return jsonDecode(profileString);
    }
    return null;
  }

  // Current Balance
  static Future<void> saveCurrentBalance(double balance) async {
    await _prefs?.setDouble('current_balance', balance);
  }

  static double getCurrentBalance() {
    return _prefs?.getDouble('current_balance') ?? 0.0;
  }

  // Income and Expenses
  static Future<void> saveIncome(double income) async {
    await _prefs?.setDouble('total_income', income);
  }

  static double getIncome() {
    return _prefs?.getDouble('total_income') ?? 0.0;
  }

  static Future<void> saveExpenses(double expenses) async {
    await _prefs?.setDouble('total_expenses', expenses);
  }

  static double getExpenses() {
    return _prefs?.getDouble('total_expenses') ?? 0.0;
  }

  // Budget Plans
  static Future<void> saveBudgetPlans(
    List<Map<String, dynamic>> budgets,
  ) async {
    await _prefs?.setString('budget_plans', jsonEncode(budgets));
  }

  static List<Map<String, dynamic>> getBudgetPlans() {
    final budgetsString = _prefs?.getString('budget_plans');
    if (budgetsString != null) {
      final List<dynamic> budgetsList = jsonDecode(budgetsString);
      return budgetsList.cast<Map<String, dynamic>>();
    }
    return [];
  }

  // Financial Goals
  static Future<void> saveFinancialGoals(
    List<Map<String, dynamic>> goals,
  ) async {
    await _prefs?.setString('financial_goals', jsonEncode(goals));
  }

  static List<Map<String, dynamic>> getFinancialGoals() {
    final goalsString = _prefs?.getString('financial_goals');
    if (goalsString != null) {
      final List<dynamic> goalsList = jsonDecode(goalsString);
      return goalsList.cast<Map<String, dynamic>>();
    }
    return [];
  }

  // Bookmarks
  static Future<void> saveBookmarks(
    Map<String, List<Map<String, dynamic>>> bookmarks,
  ) async {
    await _prefs?.setString('bookmarks', jsonEncode(bookmarks));
  }

  static Map<String, List<Map<String, dynamic>>> getBookmarks() {
    final bookmarksString = _prefs?.getString('bookmarks');
    if (bookmarksString != null) {
      final Map<String, dynamic> bookmarksMap = jsonDecode(bookmarksString);
      return bookmarksMap.map(
        (key, value) => MapEntry(key, List<Map<String, dynamic>>.from(value)),
      );
    }
    return {'budgets': [], 'emergencies': []};
  }

  // Categories
  static Future<void> saveExpenseCategories(
    List<Map<String, dynamic>> categories,
  ) async {
    await _prefs?.setString('expense_categories', jsonEncode(categories));
  }

  static List<Map<String, dynamic>> getExpenseCategories() {
    final categoriesString = _prefs?.getString('expense_categories');
    if (categoriesString != null) {
      final List<dynamic> categoriesList = jsonDecode(categoriesString);
      return categoriesList.cast<Map<String, dynamic>>();
    }
    return _getDefaultExpenseCategories();
  }

  static Future<void> saveIncomeCategories(
    List<Map<String, dynamic>> categories,
  ) async {
    await _prefs?.setString('income_categories', jsonEncode(categories));
  }

  static List<Map<String, dynamic>> getIncomeCategories() {
    final categoriesString = _prefs?.getString('income_categories');
    if (categoriesString != null) {
      final List<dynamic> categoriesList = jsonDecode(categoriesString);
      return categoriesList.cast<Map<String, dynamic>>();
    }
    return _getDefaultIncomeCategories();
  }

  // App Settings
  static Future<void> saveAppSettings(Map<String, dynamic> settings) async {
    await _prefs?.setString('app_settings', jsonEncode(settings));
  }

  static Map<String, dynamic> getAppSettings() {
    final settingsString = _prefs?.getString('app_settings');
    if (settingsString != null) {
      return jsonDecode(settingsString);
    }
    return {
      'theme': 'light',
      'language': 'English',
      'currency': 'THB',
      'monthly_start_date': 1,
      'daily_reminder': false,
      'reminder_time': '09:00',
    };
  }

  // Transactions
  static Future<void> saveTransactions(
    List<Map<String, dynamic>> transactions,
  ) async {
    await _prefs?.setString('transactions', jsonEncode(transactions));
  }

  static List<Map<String, dynamic>> getTransactions() {
    final transactionsString = _prefs?.getString('transactions');
    if (transactionsString != null) {
      final List<dynamic> transactionsList = jsonDecode(transactionsString);
      return transactionsList.cast<Map<String, dynamic>>();
    }
    return [];
  }

  // Onboarding Status
  static Future<void> setOnboardingCompleted(bool completed) async {
    await _prefs?.setBool('onboarding_completed', completed);
  }

  static bool isOnboardingCompleted() {
    return _prefs?.getBool('onboarding_completed') ?? false;
  }

  // Default Categories
  static List<Map<String, dynamic>> _getDefaultExpenseCategories() {
    return [
      {'name': 'Food', 'icon': 'Icons.restaurant', 'color': 'Colors.orange'},
      {'name': 'Daily', 'icon': 'Icons.shopping_cart', 'color': 'Colors.blue'},
      {
        'name': 'Transport',
        'icon': 'Icons.directions_car',
        'color': 'Colors.green',
      },
      {'name': 'Social', 'icon': 'Icons.people', 'color': 'Colors.purple'},
      {'name': 'Education', 'icon': 'Icons.school', 'color': 'Colors.indigo'},
      {
        'name': 'Health',
        'icon': 'Icons.medical_services',
        'color': 'Colors.red',
      },
      {'name': 'Entertainment', 'icon': 'Icons.movie', 'color': 'Colors.pink'},
      {'name': 'Utilities', 'icon': 'Icons.home', 'color': 'Colors.brown'},
      {'name': 'Others', 'icon': 'Icons.more_horiz', 'color': 'Colors.grey'},
    ];
  }

  static List<Map<String, dynamic>> _getDefaultIncomeCategories() {
    return [
      {'name': 'Salary', 'icon': 'Icons.work', 'color': 'Colors.green'},
      {'name': 'Freelance', 'icon': 'Icons.computer', 'color': 'Colors.blue'},
      {
        'name': 'Investment',
        'icon': 'Icons.trending_up',
        'color': 'Colors.purple',
      },
      {'name': 'Gift', 'icon': 'Icons.card_giftcard', 'color': 'Colors.pink'},
      {
        'name': 'Allowance',
        'icon': 'Icons.account_balance_wallet',
        'color': 'Colors.orange',
      },
      {'name': 'Others', 'icon': 'Icons.more_horiz', 'color': 'Colors.grey'},
    ];
  }
}
